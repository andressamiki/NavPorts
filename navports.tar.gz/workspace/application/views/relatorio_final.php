<main class="container">

    <div class="col-md-10 col-md-offset-1">
      <div class="row" >
            <h2 class="text-center">Relatório final</h2>
  			    <hr>
      </div> <!--/.row-->

      <div class="row" >
            <h4>Quantidade de questões respondidas: <strong>10</strong></h4>
            <h4>Quantidade de questões  <span class="text-success"> certas: <strong>4</strong></h4></span>
            <h4>Quantidade de questões <span class="text-danger">erradas: <strong>6</strong></span></h4>
      </div> <!--/.row-->
      <br>
      <div class="row" >
            <h3 class="text-center rel-h3">Perguntas respondidas</h3><br>
            <h4 class="rel-h4">Carvão, grãos, fertilizantes e cimento, são exemplos de que tipo de carga?</h4>
            <p class="text-success text-uppercase rel-p">certo</p>
            <h4 class="rel-h4">O porto de Santos possui:</h4>
            <p class="text-danger text-uppercase rel-p">errado</p>
            <h4 class="rel-h4">A Intermodalidade é o processo de</h4>
            <p class="text-success text-uppercase rel-p">certo</p>
            <h4 class="rel-h4">O que é cabotagem?</h4>
            <p class="text-danger text-uppercase rel-p">errado</p>
            <h4 class="rel-h4">Quantos berços exclusivos de atracação a Petrobras possui no Porto de Santos ?</h4>
            <p class="text-danger text-uppercase rel-p">errado</p>
            <h4 class="rel-h4">Atracação quer dizer?</h4>
            <p class="text-success text-uppercase rel-p">certo</p>
            <h4 class="rel-h4">O procedimento de desova ou desunitização refere-se a:</h4>
            <p class="text-danger text-uppercase rel-p">errado</p>
            <h4 class="rel-h4">O que é transporte unimodal ?</h4>
            <p class="text-success text-uppercase rel-p">certo</p>
            <h4 class="rel-h4">Qual o órgão que gerencia as questões de segurança e saúde no trabalho portuário e evita as diferenças de procedimentos ?</h4>
            <p class="text-danger text-uppercase rel-p">errado</p>
            <h4 class="rel-h4">Qual o produto que é exportado em maior quantidade pelo Porto de Santos ?</h4>
            <p class="text-danger text-uppercase rel-p">errado</p>
      </div> <!--/.row-->

    </main> <!--/.container -->