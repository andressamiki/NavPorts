    <main class="container">
        <main>
        <h2 class="text-center">Patrocinadores</h2>
  			<hr>
  			
  			<div class="row col-md-10 col-md-offset-1 ">
          <div class="col-md-4 col-md-offset-4">
            <a href="#" target=_blank><img src="na-moral2.png" alt="Na Moral" class="img-responsive">
            <p class="text-center">Na Moral</p></a>
          </div>
          
        </div> <!--/.row-->
        </main>
    </main> <!--/.container -->

    