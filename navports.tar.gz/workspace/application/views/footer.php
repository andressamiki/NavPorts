<br><br><br><br>
    
<footer class="footer navbar-static-bottom">
	<div class="container">
	    <div class="col-md-6" style="margin-top:10px">
			<p class="text-center">ForWebTrends 2016. Todos os direitos reservados.</p>
		</div>
		
		<div class="col-md-6">
			<div class="col-md-2 col-xs-3">
				<a href="http://fatecrl.edu.br/" target=_blank><img src="/static/img/logo_fatec.png" alt="logo-fatec" width="76px" height="40px" title="Fatec Rubens Lara"></a>
			</div>
			<div class="col-md-2 col-md-offset-1 col-xs-3">
		    	<a href="http://www.centropaulasouza.sp.gov.br/" target=_blank><img src="/static/img/logo_cps.png" width="57px" height="40px" alt="logo-centro-paula-souza" title="Centro Paula Souza"></a>
		    </div>
			<div class="col-md-2 col-xs-3">
		    	<a href="http://www.saopaulo.sp.gov.br/" target=_blank><img src="/static/img/logo-sp.png" alt="logo-governo-sao-paulo" title="Governo do Estado de São Paulo"></a>
		   	</div>
	    </div>
	</div>
</footer>
   
  </div><!--/.geral -->  
  </body>

</html>