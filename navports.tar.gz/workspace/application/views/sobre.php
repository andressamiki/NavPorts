<main class="container">
    <div class="row" >
      <h2 class="text-center">Sobre</h2>
			<hr>
    </div> <!--/.row-->
			
		<div class="col-md-10 col-md-offset-1 text-justify">
			<p class="sobre-p">&nbsp &nbsp Somos uma equipe formada por estudantes do curso Superior de Tecnologia de Sistemas para Internet, da Faculdade de Tecnologia da Baixada Santista Rubens Lara, apaixonados por este universo. Queremos unir conhecimento e diversão e acreditamos que isto é possível!</p>
      <p class="sobre-p">&nbsp &nbsp Sendo assim, em parceria com o Prof. Julio Raymundo, coordenador do curso de Gestão Portuária e seus alunos, decidimos desenvolver o projeto NavePorts. Trata-se de uma plataforma com o principal objetivo de transmitir o conhecimento, e proporcionar, de forma simples, uma experiência agradável ao usuário.</p>
      <p class="sobre-p">&nbsp &nbsp Com ele você poderá interagir com um Quiz, atualizar-se e principalmente conhecer um pouco mais sobre a área portuária e seus processos logísticos.</p>
      <p class="sobre-p">&nbsp &nbsp É fácil: analise a questão e clique na opção desejada para respondê-la. Divirta-se, informe-se.</p>
		</div>
  </main> <!--/.container -->