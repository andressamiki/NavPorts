<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>NavePorts - Navegando pelo porto de Santos</title>

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>static/css/bootstrap.min.css">

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script type="text/javascript" src="<?php echo base_url(); ?>static/js/jquery-1.11.3.min.js"></script>
    
    <!-- Latest compiled and minified JavaScript -->
    <script type="text/javascript" src="<?php echo base_url(); ?>static/js/bootstrap.min.js"></script>

    <!-- Normalize StyleSheet for default values -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>static/css/normalize.min.css">

    <!-- tamanho do h1 -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>static/css3/bootstrap.min.css">
    
    <script src="https://code.jquery.com/jquery-1.11.3.js"></script>

    <!-- StyleSheet for this template -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>static/css/main.min.css">
    
    <link rel="shortcut icon" href="<?php echo base_url();?>static/img/favicon.png" type="image/x-icon">
    
    <!-- MyIcons / FlatIcons -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>static/MyIcons/flaticon.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Condensed' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Dosis' rel='stylesheet' type='text/css'>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->



    <!-- JQuery extends Function for Redirec with post | $_POST[''] -->
    <script type="text/javascript" src="<?php echo base_url(); ?>static/js/_redirect-post.js"></script>
    
    <!-- Functions for Cookies -->
    <script type="text/javascript" src="<?php echo base_url(); ?>static/js/_cookies.js"></script>
    
		<script>
        setCookie("perguntas","");
		</script>
		
		<script>
			function newQuestion(){
				var url = "https://navports-mindsvirtual.c9users.io/";
				$.ajax({
					method: "POST",
					url: url+"Controuser/webServiceRandomSearch",
					dataType: "json",
					data: { 
						parametro: "1,2,3"
					}
				}).done(function( data ){
					var p = $("#perg");
					
					$.ajax({
						method: "POST",
						url: url+"Controuser/webServiceGetAnswer/"+data.id_pergunta ,
						dataType: "json"
					}).done(function(data2){
						p.html("");
						p.append("<h3 class='text-center'>" + data.nm_pergunta + "</h3></br>");
						p.append("<ul class=\"list-group\">")
						for(var r in data2){
							p.append( "<li onclick='saveDados("+ data2[r].id_pergunta +","+ data2[r].id_alternativa +");newQuestion();' class='list-group-item mouse' style='margin-bottom:1%;'><label class='mouse'><p class='text-info mouse' style='margin-bottom:0; font-weight:normal; '>"+ data2[r].ds_alternativa +"</p><label></li>" );
						}
						p.append("</ul>")
					});
				});
			}
			function saveDados(id_pergunta, id_alternativa){
			    
			   	// getCookie("perguntas") = id_pergunta-id_resposta,id_pergunta-id_resposta";
			   	// getCookie("perguntas") = 98-135,76-210";
			   	
			   	var li = $("#perg li");
			   	
			   	
			   	li.attr("onclick","newQuestion();");
			   	
			   	if( getCookie("perguntas")!= "" ){
			   	  setCookie("perguntas",getCookie("perguntas")+","+id_pergunta+"-"+id_alternativa,0.12);
			   	}else{
			   	  setCookie("perguntas",id_pergunta+"-"+id_alternativa,0.12);
			   	}
			}
		</script>
		
		
		<script>
			var tempo = new Number();
			// Tempo em segundos
			tempo = 60;

			function startCountdown(){

    			// Se o tempo não for zerado

    			if((tempo - 1) >= 0){

        			// Pega a parte inteira dos minutos
        			var min = parseInt(tempo/60);

        			// Calcula os segundos restantes
        			var seg = tempo%60;

        			// Formata o número menor que dez, ex: 08, 07, ...
        			if(min < 10){
            			min = "0"+min;
            			min = min.substr(0, 2);
			        }

        			if(seg <=9){
			            seg = "0"+seg;
			        }

        			// Cria a variável para formatar no estilo hora/cronômetro
        			horaImprimivel =  min + ':' + seg;

        			//JQuery pra setar o valor
        			$("#contador").html(horaImprimivel);

        			// Define que a função será executada novamente em 1000ms = 1 segundo
			        setTimeout('startCountdown()',1000);

        			// diminui o tempo
			        tempo--;

    				// Quando o contador chegar a zero faz esta ação
			    } else {
			        $("#perg").fadeOut("slow","swing");
			        
			         
			        $("body").append('<audio src=\"<?php echo base_url(); ?>static/audio/buzina-de-navio.mp3\" volume=300 autoplay>');
			        
			        // monta uma string em Formato Json
			        var perguntas = getCookie("perguntas").split(",");
			        var aux = '{&quot;perguntas&quot;: [';
			        
			        $.each(perguntas, function(key,value){
			         
		            var p = value.split('-')[0];
		            var r = value.split('-')[1];
		            aux += '{&quot;id_pergunta&quot;:'+ p +',&quot;id_resposta&quot;:'+ r +'}';
		            aux += (perguntas.length != key+1) ? ',' : '' ;
			        });
			        aux += "]}";
			     
		          var url = "relatorio-final";
			        setTimeout( function (){ $.redirectPost(url, {perg_resp: aux}) } , 2000);
			        //window.location.replace();
			    }
			}

			// Chama a função ao carregar a tela
			startCountdown();
		</script>
		

</script>

  <style>
    li.list-group-item{
      height:50px;
      
    }
    .mouse{
      cursor:pointer;
    }
    
    audio{
      display:none;
      
    }
    
    
  </style>
		
	</head> 
  <body onload="newQuestion()">
    
  <div id="geral">

   <!-- Static navbar -->
    <nav class="navbar navbar-default navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>

        <div id="oval" class="hidden-xs"> 
            <a href="home"><img src="<?php echo base_url();?>static/img/logo-3.png" height="120px" width="150px"></a>
        </div>
        <?php $dominio= parse_url($_SERVER['REQUEST_URI']); ?>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav ">
            <?php if($dominio['path'] === "/home"){ ?>
            
              <li <?php echo "id=active"; ?> ><a href="<?php echo base_url(); ?>home">home</a></li>
              <li><a href="<?php echo base_url(); ?>sobre">sobre</a></li>
              <li><a href="<?php echo base_url(); ?>contato">contato</a></li>
              
              <?php }else if($dominio['path'] === "/sobre"){?>
              
                <li ><a href="<?php echo base_url(); ?>home">home</a></li>
                <li  <?php echo "id=active"; ?>><a href="<?php echo base_url(); ?>sobre">sobre</a></li>
                <li><a href="<?php echo base_url(); ?>contato">contato</a></li>
                
                <?php }else if($dominio['path'] === "/contato"){?>
                
                <li><a href="<?php echo base_url(); ?>home">home</a></li>
                <li><a href="<?php echo base_url(); ?>sobre">sobre</a></li>
                <li <?php echo "id=active";?>><a href="<?php echo base_url(); ?>contato">contato</a></li>
                
                <?php }else{?>
                  <li><a href="<?php echo base_url(); ?>home">home</a></li>
                  <li><a href="<?php echo base_url(); ?>sobre">sobre</a></li>
                  <li><a href="<?php echo base_url(); ?>contato">contato</a></li>
                <?php }?>
          </ul>

          <ul class="nav navbar-nav navbar-right ">
            
             <?php if($dominio['path'] === "/creditos"){?>
            
              <li <?php echo "id=active";?> ><a href="<?php echo base_url(); ?>creditos">créditos</a></li>
              
            <?php }else{ ?>
              <li><a href="<?php echo base_url(); ?>creditos">créditos</a></li>
            <?php }?>
            
            <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $usu[0]['nm_usuario']; ?> <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="<?php echo base_url(); ?>painel-user" class="text-center">início</a></li>
                    <li><a href="<?php echo base_url(); ?>logout" class="text-center">sair</a></li>
                  </ul>
                </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>  
	

		
		
		<!--<div id="pergunta"></div>
		<div id="resposta"></div>
		<div id="botoes">
			<button onclick="saveDados();newQuestion();">Enviar</button>
			
		</div>-->
		 <div class="container" >
         <div class="row">
          <span class="col-md-2 pull-right">
            <p><strong id="contador"></span></strong></p>
          </span>
      </div>
		<ol class="breadcrumb" style="margin-bottom: 20px;margin-top: 35px;">
          <li><a href="<?php echo base_url();?>modo-jogo">Modo de jogo</a></li>
          <li class="active">Pergunta</li>
        </ol>
        
      <div class="col-md-10 col-md-offset-1" id="perg">  
        
        
	      
        

                
  
      </div><!--/.cols -->

    </div><!--/.container -->
		
		

<br><br><br><br>
    
<footer class="footer navbar-static-bottom">
	<div class="container">
	    <div class="col-md-6" style="margin-top:10px">
			<p class="text-center">Creative Web 2016. Todos os direitos reservados.</p>
		</div>
		
		<div class="col-md-6">
			<div class="col-md-2 col-xs-3">
				<a href="http://fatecrl.edu.br/" target=_blank><img src="/static/img/logo_fatec.png" alt="logo-fatec" width="76px" height="40px" title="Fatec Rubens Lara"></a>
			</div>
			<div class="col-md-2 col-md-offset-1 col-xs-3">
		    	<a href="http://www.centropaulasouza.sp.gov.br/" target=_blank><img src="/static/img/logo_cps.png" width="57px" height="40px" alt="logo-centro-paula-souza" title="Centro Paula Souza"></a>
		    </div>
			<div class="col-md-2 col-xs-3">
		    	<a href="http://www.saopaulo.sp.gov.br/" target=_blank><img src="/static/img/logo-sp.png" alt="logo-governo-sao-paulo" title="Governo do Estado de São Paulo"></a>
		   	</div>
	    </div>
	</div>
</footer>
   
  </div><!--/.geral -->  
  </body>

</html>
