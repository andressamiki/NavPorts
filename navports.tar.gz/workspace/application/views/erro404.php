    <main class="container" >
      <div class="row">
        
        <div class="col-md-10 col-md-offset-1 text-center">
            <h1 style="font-size:80px;margin-top:50px">404</h1>
            <h3 style="margin-top:-40px;">OPS! Acho que deu algo errado!</h3>
            <p>Tente novamente ou retorne para a <a href="home">página inicial</a>, se preferir.</p>
            <img src="<?php echo base_url(); ?>static/img/erro.jpg" alt="navio afundando" class="img-responsive img-rounded center-block" style="opacity: 0.4;margin-bottom:40px;">
        </div><!--/.cols -->
      
      </div>
    </main><!--/.container -->