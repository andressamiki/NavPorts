

    <main class="container">
      <div class="row">
        <h2 class="text-center">Modo de jogo</h2>
        <hr class="col-md-4 col-md-offset-4">
      </div>
      <div class="row">
        <p class="text-uppercase text-muted text-center">Escolha uma forma de jogo para começar sua partida.</p>
     </div>
      
      <br>

      <div class="row">
        <div class="col-md-4 col-md-offset-2">
          <p><a href="aleatorio" class="btn3d btn btn-primary btn-lg btn-block" role="button">aleatório</a></p>
        </div>
        <div class="col-md-4">
          <p><a href="categorias" class="btn3d btn btn-primary btn-lg btn-block">estudo</a></p>
        </div>
      </div>

      <br>

      <div class="row">
        <div class="col-md-4 col-md-offset-2">
          <h5>* Responda o maior número de questões em um intervalo de 3 (três) minutos.</h5>
        </div>
        <div class="col-md-4">
          <h5>* Escolha a categoria e qual questão responder.</h5>
        </div>
      </div>

    </main> <!--/.container -->