<script>
  $(function(){
    var detalhe = $('.nome');
    $(window).load(function(){
      detalhe.addClass("nome2");
  });
});
</script>

   <main class="container">
      <div class="row">
          
        <div class="col-md-8 col-md-offset-2">
          <h1 class="text-uppercase text-center">teste seus conhecimentos da área portuária</h1>
        </div>
        
        <div class="col-md-2 col-md-offset-5">
          <a href="<?php echo $redict; ?>" class="btn3d btn btn-primary btn-lg text-center nome">JOGUE AGORA</a>
        </div>
        
      </div>
    </main><!--/.container -->


    