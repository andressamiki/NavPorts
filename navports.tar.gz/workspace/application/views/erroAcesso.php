<main class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1" style="margin-top:80px">
            <h3 class="text-center">Você não tem permissão para acessar esta página. Faça o <a href="login"><strong>login</strong></a> ou retorne para a <a href="home"><strong>página inicial</strong></a>.</h3>
        </div>
    </div>
</main>
</body>
</html>