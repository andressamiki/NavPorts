    <main class="container">
        <main>
        <h2 class="text-center">Créditos</h2>
  			<hr>
  			<section class="col-md-10 col-md-offset-1">
          <h4 class="text-center">Esse é o pessoal que desenvolveu o NavePorts como quiz online.</h4>
        </section>
  			
  			<div class="row col-md-10 col-md-offset-1">
          <div class="col-md-2 col-xs-4">
            <a href="https://br.linkedin.com/in/andressa-de-souza-miki-022630b2" target=_blank><img src="<?php echo base_url(); ?>static/img/andressa.jpg" alt="Andressa Miki" class="img-responsive img-circle">
            <p class="text-center">Andressa Miki</p></a>
            <p class="text-center">DBA/Back-end</p>
          </div>
          <div class="col-md-2 col-md-offset-1 col-xs-4">
            <a href="https://br.linkedin.com/in/bruna-stella-fernandes-pinto-0a532077" target=_blank><img src="<?php echo base_url(); ?>static/img/bruna.jpg" alt="Bruna Stella" class="img-responsive img-circle">
            <p class="text-center">Bruna Stella</p></a>
            <p class="text-center">Criação de conteúdo</p>
          </div>
          <div class="col-md-2 col-md-offset-1 col-xs-4">
            <a href="https://www.linkedin.com/in/diandra-leão-717193b7" target=_blank><img src="<?php echo base_url(); ?>static/img/diandra.jpg" alt="Diandra Leão" class="img-responsive img-circle">
            <p class="text-center">Diandra Leão</p></a>
            <p class="text-center">Front-end</p>
          </div>
          <div class="col-md-2 col-md-offset-1 col-xs-4">
            <a href="https://www.linkedin.com/m/profile/ACoAABcQzbgBBsA7glObDrFia5g5XQaoWWM1fQs/" target=_blank><img src="<?php echo base_url(); ?>static/img/fabiana.jpg" alt="Fabiana Moraes" class="img-responsive img-circle">
            <p class="text-center">Fabiana Moraes</p></a>
            <p class="text-center">Front-end</p>
          </div>
        </div> <!--/.row-->

        <div class="row col-md-10 col-md-offset-1">
          <div class="col-md-2 col-xs-4">
            <a href="" target=_blank><img src="<?php echo base_url(); ?>static/img/ivan.jpg" alt="Ivan Almeida" class="img-responsive img-circle">
            <p class="text-center">Ivan Almeida</p></a>
            <p class="text-center">DBA</p>
          </div>
          <div class="col-md-2 col-md-offset-1 col-xs-4">
            <a href="" target=_blank><img src="<?php echo base_url(); ?>static/img/natalia2.jpg" alt="Natalia Coutinho" class="img-responsive img-circle">
            <p class="text-center">Natália Coutinho</p></a>
            <p class="text-center">Designer/front-end</p>
          </div>
          <div class="col-md-2 col-md-offset-1 col-xs-4">
            <a href="" target=_blank><img src="<?php echo base_url(); ?>static/img/roberto.jpg" alt="Roberto Conceição" class="img-responsive img-circle">
            <p class="text-center">Roberto Conceição</p></a>
            <p class="text-center">Back-end</p>
          </div>
          <div class="col-md-2 col-md-offset-1 col-xs-4">
            <a href="" target=_blank><img src="<?php echo base_url(); ?>static/img/rosilene.JPG" alt="Rosilene Silva" class="img-responsive img-circle">
            <p class="text-center">Rosilene Silva</p></a>
            <p class="text-center">Gerente geral</p>
          </div>
        </div> <!--/.row-->

        <div class="row">
          <div class="col-md-2 col-md-offset-5 col-xs-6">
            <a href="https://www.linkedin.com/in/walter-baleco-620636b2" target=_blank><img src="<?php echo base_url(); ?>static/img/walter.jpg" alt="Walter Baleco" class="img-responsive img-circle center-block">
            <p class="text-center">Walter Baleco</p></a>
            <p class="text-center">Gerente de processos/<br>Auxiliar geral</p>
          </div>
        </div> <!--/.row-->
        </main>
    </main> <!--/.container -->

    