<main class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1" style="margin-top:80px">
            <h3 class="text-center">O e-mail solicitado (<strong><?php echo $email;?></strong>) já está cadastrado. Você pode alterar a senha <a href="recupera-senha"><strong>clicando aqui</strong></a> ou pode voltar à <a href="home"><strong>página inicial</strong></a>.</h3>
        </div>
    </div>
</main>
