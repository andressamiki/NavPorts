<?php

class Categoria{
    
    public $nm_categoria;
    
    public function __construct($nm_categoria){
        $this->nm_categoria = $nm_categoria ;
    }
}